#!/usr/bin/env python3
# Copyright 2004-present Facebook. All Rights Reserved.

# Constant representing the version of Labgraph.
VERSION = "1.0.0"
